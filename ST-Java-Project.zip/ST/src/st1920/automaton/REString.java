package st1920.automaton;

public class REString {
	
	private String pattern;
	
	public REString(String re) {
		pattern = re;
	}
	
	public String getREString() {
		return pattern;
	}
	
}